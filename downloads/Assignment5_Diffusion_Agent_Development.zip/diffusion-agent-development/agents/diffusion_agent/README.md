# Emerging Technology Diffusion Agent — Assignment 5

Version 0.1-test-ready; developed 2026-11-01 America/New_York. This candidate applies Rogers diffusion theory to LLM-based generative AI at general technology, application/peer, and organizational levels. It informs timing and peer-position judgment; it does not make the full adoption decision.

## What is ready

Specialist instructions implement all five adopter categories, five diffusion characteristics, accelerators/inhibitors, channels and actors, organizational timing, evidence discipline, uncertainty and narrow abstention within the unchanged common output schema. Three user-specified case identities/postures are implemented. Details beyond those identities are labeled hypothetical assumptions. The original scaffold tools generated three complete standalone packets with identical shared evidence.

## Evidence limitation

The dossier contains three retrieved, inspected, hashed and commit-pinned original publisher technical artifacts. They establish access and ecosystem features, not adoption rates. Original population survey/study sites were blocked by environment policy; no findings from inaccessible leads are admitted. Exact current population Rogers stage, software-peer penetration and routine hospital documentation penetration remain unsupported. The agent must qualify/abstain on these claims. Further original empirical evidence is needed for a stronger diffusion-stage assessment. See evidence/README.md and shared_snapshot.md.

## Run now

Use tests/README.md for complete independent ChatGPT instructions. Open a separate new conversation for each complete file:

- prompts/primary_v0.1_prompt.txt — mid-sized software company / Fast Follower.
- prompts/contrast_1_v0.1_prompt.txt — AI-native startup / Early Adopter.
- prompts/contrast_2_v0.1_prompt.txt — hospital clinical documentation / Conservative Adopter.

Do not run all cases in one conversation or ask for a predetermined stage. Save unedited actual JSON responses under responses/ with the filenames in tests/test_plan.json. No real outputs exist yet.

## Local checks and rebuild

From the repository root, with standard-library Python 3:

```sh
python tools/check_frozen_core.py
python agents/diffusion_agent/tests/check_development.py
```

For a newly authorized revision, use the original builder and NEW filenames; for example:

```sh
python tools/build_prompt.py --agent agents/diffusion_agent --case agents/diffusion_agent/cases/primary.json --out agents/diffusion_agent/prompts/primary_next_prompt.txt
```

Do not overwrite retained packets/raw responses. The initial manifests describe v0.1; a revision requires updated version/manifests and honest new checks. No pip install or API key is needed. ChatGPT is the interactive model runtime.

## Status and later work

Structural/integrity results are in records/structural_checks.json. They do not establish agent reasoning quality. Read records/test_log.md for the three pending runs, records/development_log.md for the observed evidence weakness, and records/requirements_traceability.md for implementation versus pending requirements. Actual output failure/revision evidence, finalized Agent Record, independent judgment/report, reflection and final submission ZIP await real outputs and user review. The development ZIP is only a test handoff, not a submission artifact. No commit or push was made.

For the future Adoption Agent: inherit the evidence limits, separate availability from routine adoption, require comparable denominators and local quality evidence, and retain accountable human authority. Organization posture may alter the timing of reversible learning; it cannot rewrite general diffusion facts.
