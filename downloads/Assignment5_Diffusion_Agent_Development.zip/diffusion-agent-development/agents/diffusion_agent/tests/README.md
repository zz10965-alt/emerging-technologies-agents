# Independent ChatGPT test protocol

Status: three runs PENDING. Local structural checks are not agent-performance tests.

1. Open a NEW independent ChatGPT conversation for each packet. Use the same model and reasoning setting for comparability. Do not include earlier runs, desired conclusions or this review rubric in the run conversation. Treat the packet as the complete run request. Do not use browsing for this closed-snapshot comparison.
2. Upload or paste the ENTIRE matching .txt packet from prompts/. Say: “Execute this complete packet for its included case. Use only its supplied evidence and return the complete required JSON object.” If ChatGPT cannot read the full attachment, paste the full text; do not truncate, summarize or replace it with a link. Each packet includes the frozen instructions, metadata, specialist logic, one full case, shared evidence and complete output schema. No other attachments are required.
3. Record actual test date/time, ChatGPT model/settings, browsing disabled, packet SHA-256 from records/packet_manifest.json, chat/export reference if available, and any limitations of the runtime record. The packet version was built on 2026-11-01 America/New_York; record the actual run date separately. Do not reuse a historical runtime label.
4. Save the actual complete returned JSON without edits to responses/primary_v0.1_run1.json, responses/contrast_1_v0.1_run1.json and responses/contrast_2_v0.1_run1.json, respectively. Do not overwrite files. If the output contains fences or prose, preserve that raw result first (e.g., an unused .txt filename) and record any extraction into a separate JSON file. Do not repair a model error invisibly.
5. From /workspace/emerging-technologies-agents run:

```sh
python tools/validate_response.py agents/diffusion_agent/responses/primary_v0.1_run1.json
python tools/validate_response.py agents/diffusion_agent/responses/contrast_1_v0.1_run1.json
python tools/validate_response.py agents/diffusion_agent/responses/contrast_2_v0.1_run1.json
python agents/diffusion_agent/tests/check_development.py --responses
python tools/check_frozen_core.py
```

The original validator checks the basic contract. The supplemental checker enforces the frozen output schema's required fields, string/array/object item types, agent fields, and prohibition on additional top-level properties. Neither proves analytical quality. A failure is evidence to preserve, not permission to edit an original response.

6. Use test_plan.json for semantic review. Compare general findings first, then application/peer findings and timing. Quote one conclusion that stayed stable and one that changed appropriately, with reasons. Specifically check for posture-driven stage drift, fabricated adoption percentages, claims from blocked leads, transfer of coding evidence into hospitals, five-factor genericism, and full-adoption advice. Abstention on unsupported numerical stages is expected, not an automatic failure.
7. Preserve at least one actual informative weakness in records/test_log.md, quote it and link its raw response, identify the cause and revision/control, and retest with a new unused version/run filename. If no weakness is found, say so and identify an honest stress-test need rather than manufacturing failure. Do not fill the Agent Record or personal reflection from hypothetical tests.
8. Send all three actual outputs back for diagnosis and revision. Agent Record, half-page independent judgment, AI/verification submission note, Craft Gained reflection, submission ZIP, and commit/push wait until actual results and user review. A development AI note exists now as provenance, not a finalized student judgment.
