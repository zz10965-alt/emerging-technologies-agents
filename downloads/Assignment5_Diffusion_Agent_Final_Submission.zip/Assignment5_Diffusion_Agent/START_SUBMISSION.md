# Assignment 5 Diffusion Agent — final submission materials

Open agents/diffusion_agent/submission/ for the six editable Word documents and SUBMISSION_CHECKLIST.md. The official Agent Record uses the supplied template. The Primary output report is an unabridged readable presentation of the actual Primary v0.3 response; exact original JSON bytes are retained under responses/.

TEST LINEAGE: three original v0.2 case tests (Primary, Startup, Hospital) and two targeted v0.3 retests (Primary, Hospital). Exactly five actual outputs. Startup was NOT rerun under v0.3 and remains contrast_1_v0.2_run1.json. See release_manifest.json and the validation/retest records.

Run from this extracted root: python agents/diffusion_agent/tests/check_final_submission.py
No API key, network request or pip installation is required. Omit --full-repository in this portable archive: previous Assignment 4 files are intentionally excluded from the ZIP but remain unchanged in the GitHub repository. Unchanged frozen tools/core and template prerequisites are included.

The six-month planning duration and shared diffusion-v0.2 evidence remain consistent. Dates in older metadata/packets record preparation-time state, not actual execution dates. Current actual-test status is in the release and validation manifests. Independent Judgment and Craft Gained are AI-assisted proposed wording for student confirmation before submission.

Agent/test evidence commit: 6db612dd3d6dba141c1ee711ae7a8cb7ed1e9903. The final delivery commit is reported separately once GitHub confirms push. PACKAGE_SHA256.json covers every archive file except itself. This preserves an inspectable archive without a circular self-hash.
