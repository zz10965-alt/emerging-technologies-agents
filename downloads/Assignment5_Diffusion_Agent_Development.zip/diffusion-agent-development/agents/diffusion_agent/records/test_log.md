# Test log — pending actual independent runs

| Case | Structural preparation | Actual ChatGPT run | Output contract | Semantic review |
|---|---|---|---|---|
| Primary: mid-sized software / Fast Follower | Packet prepared; see structural_checks.json | Not run | Not run | Not run |
| Contrast 1: AI-native startup / Early Adopter | Packet prepared; see structural_checks.json | Not run | Not run | Not run |
| Contrast 2: hospital documentation / Conservative Adopter | Packet prepared; see structural_checks.json | Not run | Not run | Not run |

No synthetic responses, claimed runtime passes or test failures are supplied. After real runs, record runtime metadata and raw-file references, stable/changed conclusions, an exact weakness quote, revision/control and new retest results. A structural preparation pass is not a real-run pass. See tests/test_plan.json.
