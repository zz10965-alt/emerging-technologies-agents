# Assignment 5 Diffusion Agent — v0.2-test-ready

This revision adds verified original empirical evidence and clearer Git provenance before formal model testing. It preserves Rogers' five adopter categories, five characteristics, three-level findings, diffusion mechanisms, organizational timing and bounded abstention within the unchanged common schema.

## Run v0.2

Use prompts/primary_v0.2_prompt.txt, contrast_1_v0.2_prompt.txt and contrast_2_v0.2_prompt.txt. Each is complete and standalone. Open a separate fresh ChatGPT conversation per packet with the same model/settings and no browsing. See tests/README.md for exact instructions and output filenames. No model tests have been run or outputs fabricated.

## Evidence added

E1 is the original 2025 DORA survey infographic plus instrument: reported individual current use and retrospective task frequency, with distinct denominators. E2 is a 2025 original empirical synthesis that reuses 2024 data and defines team incorporation/telemetry measures. E3 is original 2026 qualitative student research about moderated usage and verification. E4 is the full original 2024 survey with coding-task reliance and inspected methods, underlying E2. Product artifacts D1–D3 remain bounded ecosystem evidence. See evidence/shared_snapshot.md and source_register.json for exact dates, claims, locators, methods, source dependence and limits.

All empirical additions share DORA/Google Cloud; E2 and E4 are not independent replication. The 2025 infographic/questionnaire were verified, but the full 2025 sampling-methods report was blocked. Broad-AI technical-worker surveys do not isolate LLM-only prevalence, sustained enterprise retention or healthcare documentation penetration. Original clinical sources remain blocked; no healthcare adoption percentages are claimed. These unresolved claims remain meaningful abstentions. Older observations need refreshing.

## Version and branch provenance

Local checkout branch: work. Intended repository branch: assignment4-promethean. Live remote SHA matched local HEAD at revision verification. Metadata explicitly distinguishes these; no branch was created or switched. No commit or push occurred. Existing v0.1 download ZIP and all previous assignments remain unchanged.

The entire original 30-file v0.1 candidate is in baselines/v0.1_complete_candidate.zip with its per-file hashes. Original v0.1 packets remain byte-identical; use only v0.2 for the next formal tests. Versioned evidence controls and preparation records are distinct from real model-test results.

## Local validation

From the repository root, using standard-library Python 3:

```sh
python tools/check_frozen_core.py
python agents/diffusion_agent/tests/check_development.py --full-repository
```

For a portable development ZIP without previous assignments, omit --full-repository. After actual outputs are saved, add --responses for contract validation. Source hashes and packet integrity do not validate analytical behavior. No pip install or API key is required.

records/change_manifest_v0.2.json lists exact changed/added files. records/structural_checks.json records actual preparation checks. records/test_log.md marks all formal runs pending. Agent Record, individual judgment/report, reflection and final submission ZIP remain deferred. This is a development handoff, not a final course submission or integrated adoption authorization.
