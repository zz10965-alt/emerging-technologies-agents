# Assignment 4 submission index

Student: Zhixian Zhang (Freya Zhang), NYU MS in Management and Analytics.
Agent version: 0.3-suppression-fix. Repository: https://github.com/zz10965-alt/emerging-technologies-agents
Branch: assignment4-promethean. Exact development commit: d8be121c5698bd722aa7fbe9440462cb4e633ab0

This package contains all 32 unchanged original scaffold files and all 43 committed specialist files from that candidate. Only this index, final_submission_audit.json and submission_file_hashes.json are packaging additions; they do not change the tested candidate or imply a new Git commit.

## Companion submission files (submitted separately)

- Assignment4_Agent_Record.docx: instructor's actual template filled, A–E/labels/tables retained.
- Assignment4_Individual_Report.docx: edited presentation of actual Primary v0.3 output, student's supplied independent judgment, AI/verification note, and proposed 81-word personal reflection for review.

## Reading and reproduction paths

From the extracted scaffold root, read agents/promethean_agent/README.md. Original root README/START_HERE and examples are retained course baseline, not evidence of actual Assignment 4 runs. All original manifests retain their original scope/checksums; submission_file_hashes.json covers the packaged files separately.

- Current instructions/metadata: agents/promethean_agent/specialist_instructions.md and agent_metadata.json.
- Shared inputs/evidence: agents/promethean_agent/cases/ and evidence/.
- Exact execution packets: agents/promethean_agent/prompts/*_v0.2_prompt.txt and primary_v0.3_prompt.txt. v0.1 packets are historical preparation only.
- Five unedited actual outputs: agents/promethean_agent/responses/{primary,contrast_1,contrast_2,hype_probe}_v0.2_run1.json and primary_v0.3_run1.json.
- Baseline results/provenance: records/phase4a_validation_results.json and phase4a_diagnostic_review.md under the specialist directory.
- Actual before/diff and retest evidence: records/phase4b/; see revision_log.md and test_log.md for chronology.
- Current version history: records/version_history.md. Earlier NOT EXECUTED statements in preparation-time records describe their historical state; later records document received executions.

Run from the extracted scaffold root:

```sh
python tools/check_frozen_core.py
python tools/validate_response.py agents/promethean_agent/responses/primary_v0.3_run1.json
```

The reference workflow uses standard-library Python and interactive ChatGPT, no API key. Supplemental complete-schema checks used the already installed jsonschema 4.26.0 during validation; that package is not required for the original course tools and no original dependency file was altered. Schema passes do not prove analytical correctness.

## Boundaries

Qualified Breakthrough remains the actual finding. Chapter 11's Potential Promethean generative-AI calibration is preserved as provisional. One Primary retest corrected one suppression-trigger inversion; it does not establish general reliability or revised contrast/hype performance. The residual “impossible in principle” concern remains unchanged. No raw response was edited. Runtime gaps and evidence limits remain recorded, not invented. No final submission document is an additional model test.
