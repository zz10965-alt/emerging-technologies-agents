# Evidence dossier

Read shared_snapshot.md for the complete admitted evidence and explicit gaps. source_register.json provides claims, locators, methods/denominator limits, immutable URLs and blocked leads. access_log.json records exact retrieval outcomes, byte counts and SHA-256 values; raw/D1.md–D3.md preserve original retrieved README bytes. Publication dates are not invented for undated files. Retrieval dates do not make these population studies.

The empirical adoption-evidence component is incomplete because original survey/study domains were blocked. The agent is deliberately testable with this bounded dossier: it must distinguish access from use and abstain from unsupported stage/penetration claims. Stronger evidence may change findings and requires a versioned common snapshot and new runs. Do not represent this package as a verified market-diffusion review or a tested agent.
