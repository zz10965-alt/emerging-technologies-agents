# v0.2 formal model-test log — all runs pending

| Case | Packet | Actual ChatGPT run | Output contract | Semantic adequacy |
|---|---|---|---|---|
| Primary | primary_v0.2_prompt.txt | NOT RUN | NOT RUN | NOT TESTED |
| Contrast 1 | contrast_1_v0.2_prompt.txt | NOT RUN | NOT RUN | NOT TESTED |
| Contrast 2 | contrast_2_v0.2_prompt.txt | NOT RUN | NOT RUN | NOT TESTED |

v0.1 was structurally prepared but not formally model-tested. v0.2 adds source verification and structural checks, not fabricated model outcomes. No response JSON files were created. The actual output weakness/revision/retest record is deferred until real results exist. The v0.1 snapshot includes the original pending test log unchanged.
